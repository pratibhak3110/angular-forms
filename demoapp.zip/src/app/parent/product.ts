export class Product1{
    constructor(public pname:string,
      public price:number){}
}

/*export class Product2{
  constructor(public pname:string,
    public price:number){}
}

export class Product3{
  constructor(public pname:string,
    public price:number){}
}

export class Product4{
  constructor(public pname:string,
    public price:number){}
}

export class Product5{
  constructor(public pname:string,
    public price:number){}
}

export class Product6{
  constructor(public pname:string,
    public price:number){}
}
export class Product7{
  constructor(public pname:string,
    public price:number){}
}*/
