export class  Employee{
  public constructor(
    public Id: string,
    public Name:string,
    public Gender:string,
    public Department:string,
  ){}
}
