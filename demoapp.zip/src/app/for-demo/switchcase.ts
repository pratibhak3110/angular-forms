export class Item{
  public constructor(
    public Name:String,
    public Value:number
  )
  {}
}
