export class Light
{
    public constructor(
      public Name:string
    )
    {}
}
