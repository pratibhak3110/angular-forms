export class TodoShow
{
  constructor(public id:number, public title:string,public status:string){

  }
}
export interface Todo2{
  id: number;
  title:string;
  status:string;
}
