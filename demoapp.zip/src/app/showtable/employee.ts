export class EmployeeShow{
  constructor(public id:number,public name:String,public age:number,public email:String, public gender:String){

  }
}
