export class Cart

{
  public  constructor(
    public pname:string,
    public price:number
  ){}
}
