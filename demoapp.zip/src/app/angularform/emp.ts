export class Employee
{
    public constructor(
      public name:string,
      public email: string,
      public password: number,
      public address: string,
      public city:string
    ){}
}
